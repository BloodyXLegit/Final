import java.awt.Color;
import java.awt.Container;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import javax.imageio.ImageIO;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.Timer;

import jdk.nashorn.internal.ir.Block;

public class Background extends JPanel implements KeyListener, ActionListener{

	Image img;
	boolean jumping, right, left, play;
	int marioX;
	static int marioY = 450;
	Image marioImage = getImage("mario.jpg", 50, 50);
	Image turtleImage = getImage("turtle.png", 250, 150);
	Image bricks = getImage("marioBricks.png", 20, 20);
	double intVelocity = -6, gravity = 0.26887, time = 1;
	double velocity = intVelocity;
	int backgroundX = 600;
	public ArrayList<Brick> arBricks;


	public Background(){
		arBricks = new ArrayList<Brick>();
		arBricks.add(new Brick(600, 500));

		Timer timer = new Timer(10, this);
		timer.start();
	}

	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		//		double ratioX = getWidth()/600.0;
		//		double ratioY = getHeight()/600.0;
		//		Graphics2D g2 = (Graphics2D) g;
		//		g2.scale(ratioX, ratioY);

		for(int i = 0; i < arBricks.size(); i++){
			arBricks.get(i).updatePosition();
		}
		for(int i = 0; i < arBricks.size(); i++){
			arBricks.get(i).draw(g);
		}
		//draw bricks



		//for(; backgroundX<30; backgroundX++) {
		//g.drawImage(bricks, backgroundX*20, 500, null);
		//}
		/*while(play){
			for(; shift < 800;) {
				g.drawImage(bricks, backgroundX+i, 500, null);
				shift+=20;
			}
			shift = 0;
			play = false;
		}*/


		// paint mario 
		g.drawImage(marioImage, marioX, (int) (marioY+velocity), null);

		if(jumping) {
			marioY += velocity*time;
			velocity += gravity*time;
			time++;

			if(marioY >= 450) {

				velocity = intVelocity;
				time = 1;
				marioY = 450;
				jumping = false;
			}

			if(right) {
				marioX += 10;
				right = false;
			}
			if(left) {
				marioX -= 10;
				left = false;
			}
		}

		if(right) {
			marioX += 10;
			right = false;
		}
		if(left) {
			marioX -= 10;
			left = false;
		}
	}

	public void walk(int d) {
		marioX+=d;
		repaint();
	}

	public void jump() {
		for(; marioY >= 350; marioY--) {
			repaint();
		}

		for(; marioY <= 449; marioY++) {
			repaint();
		}
	}


	public int inAir() {
		int h = img.getHeight(null);
		for(; h <= 500;) {
			h--;
			return h;
		}
		return h;
	}

	public Image getImage(String n, int width, int height) {
		try {
			img = ImageIO.read(new File(n));
		} catch (IOException e) {
			System.out.println("There is not image file");
		}
		if(img != null) {
			img = img.getScaledInstance(width, height, Image.SCALE_DEFAULT);
		} 
		return img;
	}

	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void keyPressed(KeyEvent e) {
		// TODO Auto-generated method stub
		int keyCode = e.getKeyCode();

		switch(keyCode) {
		case KeyEvent.VK_UP:
			jumping = true;
			break;

		case KeyEvent.VK_LEFT:
			left = true;
			break;

		case KeyEvent.VK_RIGHT:
			right = true;
			break;

		case KeyEvent.VK_ENTER:
			if(!play)
				play = true;
			else
				play = false;
		}
		repaint();
	}

	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub

	}


	public static void main(String[] args) throws InterruptedException {
//		JFrame window = new JFrame("Drawings");
//		window.setBounds(100, 100, 600, 600);
//		window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);	
//		Background back = new Background();
//		window.addKeyListener(back);
//		window.setBackground(Color.WHITE);
//		back.setBackground(Color.white);
//		window.getContentPane().add(back);
//		//window.setEnabled(false);
//		window.setVisible(true);
		
		JFrame window = new JFrame("Landscape");
		window.setBounds(0, 0, 784, 562);
		window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		JPanel canvas = new Landscape();
		canvas.setBackground(Color.WHITE);
		window.getContentPane().add(canvas);
		window.setVisible(true);
		window.setResizable(false);



	}

	@Override
	public void actionPerformed(ActionEvent arg0) {
		backgroundX--;
		play = true;
		repaint();		
	}
}
