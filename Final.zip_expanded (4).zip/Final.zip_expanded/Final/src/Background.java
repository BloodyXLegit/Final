import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.File;
import java.io.IOException;
import java.util.Timer;
import javax.imageio.ImageIO;
import javax.swing.JFrame;
import javax.swing.JPanel;

import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
public class Background extends JPanel implements KeyListener, ActionListener{

	Image img;
	boolean jumping;
	int marioX;
	static int marioY = 450;
	Image marioImage = getImage("mario.jpg", 50, 50);
	Image turtleImage = getImage("turtle.png", 250, 150);
	Image bricks = getImage("marioBricks.png", 20, 20);
	double intVelocity = 3, velocity, gravity, time = 1;
	Music music = new Music();
	EasySound Sound;

	public Background(){
		
	}

	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		double ratioX = getWidth()/600.0;
		double ratioY = getHeight()/600.0;
		Graphics2D g2 = (Graphics2D) g;
		g2.scale(ratioX, ratioY);

		//draw bricks
		for(int i = 0; i<30; i++) {
			g.drawImage(bricks, i*20, 500, null);
		}

		// paint mario 
		g.drawImage(marioImage, marioX, (int) (marioY+velocity), null);

		if(jumping) {
			marioY -= velocity*time;
			velocity += gravity*time;
			time++;
		}

		if(marioY >= 450) {
			velocity = intVelocity;
			time = 1;
			marioY = 450;
		}
		
	}

	public void walk(int d) {
		marioX+=d;
		repaint();
	}

	public void jump() {
		for(; marioY >= 350; marioY--) {
			repaint();
		}

		for(; marioY <= 449; marioY++) {
			repaint();
		}
	}


	public int inAir() {
		int h = img.getHeight(null);
		for(; h <= 500;) {
			h--;
			return h;
		}
		return h;
	}

	public Image getImage(String n, int width, int height) {
		try {
			img = ImageIO.read(new File(n));
		} catch (IOException e) {
			System.out.println("There is not image file");
		}
		if(img != null) {
			img = img.getScaledInstance(width, height, Image.SCALE_DEFAULT);
		} 
		return img;
	}

	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void keyPressed(KeyEvent e) {
		// TODO Auto-generated method stub
		int keyCode = e.getKeyCode();
		Sound = new EasySound("menumusic.wav");
		

		switch(keyCode) {
		case KeyEvent.VK_UP:
			jumping = true;
			Sound.play();
			break;

		case KeyEvent.VK_LEFT:
			walk(-5);
			break;

		case KeyEvent.VK_RIGHT:
			walk(5);
			break;
		}
		repaint();
	}

	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub

	}


	public static void main(String[] args) throws InterruptedException {
		JFrame window = new JFrame("Drawings");
		window.setBounds(100, 100, 600, 600);
		window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		Background back = new Background();
		window.addKeyListener(back);
		window.setBackground(Color.WHITE);
		back.setBackground(Color.white);
		window.getContentPane().add(back);
		//window.setEnabled(false);
		window.setVisible(true);


	}

	@Override
	public void actionPerformed(ActionEvent arg0) {
		repaint();		
	}
}
