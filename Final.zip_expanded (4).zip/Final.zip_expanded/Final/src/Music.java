import java.io.File;
import java.io.IOException;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.DataLine;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.SourceDataLine;

public class Music {
	

public Music(){
	
}
	

	
	
/*	public void play1(){
		
		try{
//          AudioInputStream ais = AudioSystem.getAudioInputStream(Main.class.getResource("bells.wav"));
            AudioInputStream ais = AudioSystem.getAudioInputStream(new File("menumusic.wav"));
           // Clip test = AudioSystem.getClip();
            test.open(ais);
            test.start();
            test.drain();
            test.close();
        }catch(Exception ex){
            ex.printStackTrace();
        }
	    
	    }
	
	 public void play2(){
		 try{
//	          AudioInputStream ais = AudioSystem.getAudioInputStream(Main.class.getResource("bells.wav"));
	            AudioInputStream ais = AudioSystem.getAudioInputStream(new File("music.wav"));
	            Clip test = AudioSystem.getClip();
	            test.open(ais);
	            test.start();
	            test.drain();
	            test.close();
	        }catch(Exception ex){
	            ex.printStackTrace();
	        }
		    
		    }
*/



	EasySound Sound;
	 }
	    
		    
	

