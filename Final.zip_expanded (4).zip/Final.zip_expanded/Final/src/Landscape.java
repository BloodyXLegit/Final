import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import javax.swing.Timer;

public class Landscape extends JPanel implements ActionListener
{
	//images
	private static Image img;
	private static Image House;
	private static Image Tree;
	private static Image Sun;
	private static Image StickFig;
	//tells whether to draw an object
	private static boolean drawHouse = false;
	private static boolean drawTree = false;
	private static boolean drawSun = false;

	private int updateRate = 30;//ms frame delay
	private static int PosX = 0;//X character position
	private static int groundY= 420;//Y pos of the ground
	private static int charHeight = 60;//height of the character
	private static int PosY = groundY - charHeight;//Y position of the character
	private final int intVelY = -10;//initial jump velocity, lower number = higher jump
	private int VelY = -intVelY;// current velocity(as a vector)
	private final double gravity = 0.26887;//acceleration due to gravity in pixels/FPS^2
	private int time = 0;//current jump time
	private static boolean jumping = false;//true while character is jumping
	//true if key and held is pressed
	static boolean up = false;
	static boolean right = false;
	static boolean left = false;
	
	private static double ratioX;
	private static double ratioY;

	public Landscape(){
		//set up timer
		Timer clock = new Timer(updateRate, this); 
		clock.start();//start timer
	}

	public void paintComponent(Graphics g)
	{
		super.paintComponent(g);

		Toolkit.getDefaultToolkit().sync();//improve performance of graphics package on Linux/Unix
		//the height and with of frame
		int width = getWidth();
		int height = getHeight();
		//scale factors
		double ratioX = width/784.0;
		double ratioY = height/562.0;
		
		Landscape.ratioX = ratioX;
		Landscape.ratioY = ratioY;
		
		//scale frame
		Graphics2D g2 = (Graphics2D)g;
		g2.scale(ratioX,ratioY);

		g.drawImage(img, 0, 0, null);//draws background images

		//draws all the images if toggled
		if(drawHouse)
			g.drawImage(House, 538,235, 148, 185, null);
		if(drawSun)
			g.drawImage(Sun, 585 , 70, 100, 95, null);
		if(drawTree)
			g.drawImage(Tree, 145, 185, 150, 250, null);

		g.drawImage(StickFig, PosX, PosY, 42, 60, null);//draws stick figure

		//jumping physics
		if(jumping){

			PosY += VelY * time;//updates character position
			VelY += gravity * time;//updates velocity based on acceleration due to gravity
			time ++;//updates time

			if(PosY > groundY - charHeight){//checks for ground collision then resets jump
				jumping = false;
				time = 0;
				PosY = groundY - charHeight;
				VelY = intVelY;
			}
		}

		if(left){
			PosX -= 10;
		}else if(right){
			PosX += 10;
		}


	}

	public static void main(String[] args)
	{
		//set file location of images
		img = (new ImageIcon("Landscape.png")).getImage();
		House = (new ImageIcon("House.jpeg")).getImage();
		Tree = (new ImageIcon("Tree.jpg")).getImage();
		Sun = (new ImageIcon("Sun.jpeg")).getImage();
		StickFig = (new ImageIcon("StickFig.png")).getImage();

		//set up JPanel
		JFrame window = new JFrame("Landscape");
		window.setBounds(0, 0, 784, 562);
		window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		JPanel canvas = new Landscape();
		canvas.setBackground(Color.WHITE);
		window.getContentPane().add(canvas);
		window.setVisible(true);
		window.setResizable(false);
		//add keyListener
		window.addKeyListener(listener);
		window.addMouseListener(mouse);

	}

	@Override
	public void actionPerformed(ActionEvent arg0) {
		repaint();		
	}

	static MouseListener mouse = new MouseListener(){
		
		@Override
		public void mouseClicked(MouseEvent e) {}

		@Override
		public void mouseEntered(MouseEvent e) {}

		@Override
		public void mouseExited(MouseEvent e) {}

		@Override
		public void mousePressed(MouseEvent e) {
			if(SwingUtilities.isRightMouseButton(e) && e.getX() > PosX && e.getX() < PosX + (42) && e.getY() > PosY && e.getY() < PosY + (60)){
				PosX = 0;
			}
			System.out.println(e.getX());
		}

		@Override
		public void mouseReleased(MouseEvent e) {
			
		}
		
	};
	
	static KeyListener listener = new KeyListener() {

		@Override
		public void keyPressed(KeyEvent e) {
			if(KeyEvent.getKeyText(e.getKeyCode()).equals("1")){
				if(drawHouse){
					drawHouse = false;
				}else{
					drawHouse = true;
				}
			}else if(KeyEvent.getKeyText(e.getKeyCode()).equals("2")){
				if(drawTree){
					drawTree = false;
				}else{
					drawTree = true;
				}
			}else if(KeyEvent.getKeyText(e.getKeyCode()).equals("3")){
				if(drawSun){
					drawSun = false;
				}else{
					drawSun = true;
				}
			}
			if(KeyEvent.getKeyText(e.getKeyCode()).equals("Up")){
				up = true;
			}
			if(KeyEvent.getKeyText(e.getKeyCode()).equals("Right")){
				right = true;
			}
			if(KeyEvent.getKeyText(e.getKeyCode()).equals("Left")){
				left = true;
			}
			if(up){
				jumping = true;
			}

		};
		@Override
		public void keyReleased(KeyEvent e) {
			if(KeyEvent.getKeyText(e.getKeyCode()).equals("Up")){
				up = false;
			}
			if(KeyEvent.getKeyText(e.getKeyCode()).equals("Right")){
				right = false;
			}
			if(KeyEvent.getKeyText(e.getKeyCode()).equals("Left")){
				left = false;
			}		
		}
		public void keyTyped(KeyEvent e) {
		}
	};



}